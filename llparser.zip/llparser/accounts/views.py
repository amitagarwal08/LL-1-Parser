from django.shortcuts import render,redirect

from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import auth

# Create your views here.
"""def login(request,username,password):
    user = auth.authenticate(username=username,password=password)
    if user is not None:
        return redirect('')
    else:
        redirect('login/')"""

    
def register(request):
    if request.method == "POST":
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password1')
            #login(request,username,password)
            return redirect('')
    form = UserCreationForm()
    return render(request,'register.html',{'form':form})

def login(request):
    if request.method == "POST":
        username = request.POST['username']
        password = request.POST['password']
        user = auth.authenticate(username=username,password=password)
        if user is not None:
            return redirect('')
    
    return render(request,'login.html')
