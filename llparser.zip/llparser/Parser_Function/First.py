def find_first(nt,dicts,non_terminals,first):
    print("In non-terminal : ",nt)
    lst = dicts[nt]
    print(lst)
    for ele in lst:
        l = ele.strip().split(" ")
        print(l)
        for i in range(len(l)):
            sy = l[i]
            if sy in non_terminals:
                if first[sy]==[]:
                    find_first(sy,dicts,non_terminals,first)
                if '^' not in first[sy] or i==len(l)-1:
                    first[nt].extend(first[sy])
                    break
                else:
                    first_sy = first[sy].copy()
                    first_sy.remove('^')
                    first[nt].extend(first[sy])
            else:
                first[nt].append(sy)
                break

    print("first of ", nt ," : ", first[nt])