def find_follow(nt,dicts,follow,first,non_terminals):
    for key in dicts:
        key_production = dicts[key]
        for pro in key_production:
            char_pro = pro.strip().split(" ")
            if nt in char_pro:
                ind = char_pro.index(nt)
                if ind==len(char_pro)-1:
                    if follow[key]==[]:
                        find_follow(key,dicts,follow,first,non_terminals)
                    follow[nt].extend(follow[key])
                else:
                    symbol = char_pro[ind+1]
                    if symbol not in non_terminals:
                        follow[nt].append(symbol)
                    else:
                        if "^" not in first[symbol]:
                            follow[nt].extend(list(first[symbol]))
                        else:
                            first_sy = list(first[symbol]).copy()
                            first_sy.remove("^")
                            follow[nt].extend(first_sy)
                            if follow[key]==[]:
                                find_follow(key,dicts,follow,first,non_terminals)
                            follow[nt].extend(follow[key])