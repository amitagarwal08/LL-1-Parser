from collections import defaultdict
from . import First,Follow,ParsingTable


def PassParameters(lst,string):
    print(lst)

    production_lst = []
    non_terminals = []    
    dicts = {}
    
    result = {'first':None,'follow':None,'parsing_table':None,'msg':None}

    for each in lst:
        s = each
        #print each production
        print(s)
        #separate non-terminal and its production
        ch = s.strip().split("-")

        #If there is no grammar symbol on right side of production
        if '-' not in s or s[len(s)-1]=='-':
            msg_string = "Error!!!! Please provide valid production"
            print("\n"+msg_string+"\n")
            result['msg'] = msg_string
            return result
        non_terminals.append(ch[0])
        sep_pro = ch[1].strip().split("|")
        dicts[ch[0]] = sep_pro
        #all_symbols.update(ter)
        production_lst.append(s)

    print("All Productions : " , production_lst)
    print("Separate production : ",dicts)
    #print("All Symbols in Grammar : " , all_symbols)
    print("All Non-terminal symbols in grammar : " , non_terminals)

    """terminals = []
    for sy in all_symbols:
        if sy not in non_terminals and sy!='|' and sy!='-':
            terminals.append(sy)"""

    """non_terminals_set = set(non_terminals)
    non_terminals_set.update(['-','|'])
    terminals = all_symbols - non_terminals_set
    print("Terminal Symbols : ", terminals)
    """
    first = defaultdict(list)

    for nt in non_terminals:
        #if first[nt] 
        #print(nt , " : " , first[nt])
        if first[nt]==[]:
            First.find_first(nt,dicts,non_terminals,first)

    print("\nFirst of all non-terminals\n")
    for key in first:
        first[key] = set(first[key])
        print(key , " : " ,first[key])


    follow=defaultdict(list)

    for nt in non_terminals:
        if follow[nt]==[]:
            if nt==non_terminals[0]:
                follow[nt].append("$")
            Follow.find_follow(nt,dicts,follow,first,non_terminals)
        print("follow of ", nt , " : " , follow[nt])

    print("\n Follow of all non-terminals\n")
    for key in follow:
        follow[key]= set(follow[key])
        print(key," : ",follow[key])


    parsing_table = defaultdict(lambda:'no-value')

    for key in dicts:
        key_production = dicts[key]
        for pro in key_production:
            d = ParsingTable.first_parsing_table(pro,key,non_terminals,first,follow)
            #print(pro , d)
            dic = parsing_table[key]
            if dic=="no-value":
                dic=defaultdict(lambda:'null')
            #print(dic)
            for ele in d:
                if dic[ele]!="null":
                    print("\n    !!!Error!!! This grammar is not LL(1)\n")
                    exit
                dic[ele]=pro
            
            #print(dic)
            
            parsing_table[key]=dic

    print("\nParsing Table\n")
    for key in parsing_table:
        print("Non-terminal ",key)
        dic = parsing_table[key]
        parsing_table[key] = dict(dic)
        print(dic)

    result['first'] = first
    result['follow'] = follow
    result['parsing_table'] = parsing_table

    #return first,follow,parsing_table


    #print("Provide input string : ")
    #inp = input().strip().split(" ")
    inp = string.strip().split(" ")
    inp.append('$')
    print(inp)
    stack = []
    stack.append('$')
    stack.append(non_terminals[0])
    print(stack)
    top = stack.pop()
    i=0
    current = inp[i]
    while(True):
        #print("In while loop")
        print("\nTop : ",top,"Current : ",current)
        print("Stack : ",stack)
        print("Input : ",inp)
        if top not in non_terminals:
            if top==current:
                if current=='$':
                    #print("\n  Input parsing successful\n\n")
                    #break
                    msg = "Input parsing successful"
                    return first,follow,parsing_table,msg
                top = stack.pop()
                i+=1
                current = inp[i]
            else:
                #print("\n     Error!!! Input string is not acceptable by given grammar\n\n")
                #exit()
                msg = "Error!!! Input string is not acceptable by given grammar"
                return first,follow,parsing_table,msg
        elif top in non_terminals:
            dic = parsing_table[top]
            pro = dic[current]
            #print(pro)
            if pro=="null":
                #print("\n     Error!!! Input string is not acceptable by given grammar\n\n")
                #exit()
                msg = "Error!!! Input string is not acceptable by given grammar"
                return first,follow,parsing_table,msg
            else:
                lst = pro.strip().split(" ")
                #print("lst : ",lst)
                for ele in reversed(lst):
                    stack.append(ele)
                top = stack.pop()

        #print("Top : ",top,"Current : ",current)