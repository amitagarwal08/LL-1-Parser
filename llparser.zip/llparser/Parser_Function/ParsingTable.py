def first_parsing_table(st,key,non_terminals,first,follow):
    d = []
    symbols = st.strip().split(" ")
    for i in range(len(symbols)):
        sy = symbols[i]
        if sy=="^":
            d.extend(list(follow[key]))
            break
        if sy not in non_terminals:
            d.append(sy)
            break
        else:
            if "^" not in first[sy]:
                d.extend(list(first[sy]))
                break
            else:
                first_sy = list(first[sy]).copy()
                first_sy.remove("^")
                d.extend(first_sy)
                if i==len(symbols)-1:
                    d.extend(list(follow[key]))
    return d