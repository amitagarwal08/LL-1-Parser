from django.shortcuts import render

from django.http import HttpResponse,JsonResponse
import json

from Parser_Function import main_fun

# Create your views here.

class SetEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, set):
            return list(obj)
        return json.JSONEncoder.default(self, obj)


def home(request):
    ##return HttpResponse("Hello World! You are in home")
    """if request.method == "GET" and request.GET.get('input_grammar') is not None:
        inp = request.GET.get('input_grammar')
        string = request.GET.get('input_string')"""
    if request.method=="POST":
        #inp = request.POST['input_grammar']
        #string = request.POST['input_string']
        data = json.loads(request.body)
        inp = data['input_grammar']
        string = data['input_string'].strip()
        print("Input Grammar\n"+inp+"\nInput String\n"+string)
        print()
        print()
        l = inp.strip().split('\n')

        print(l)
        first,follow,parsing_table,msg = main_fun.PassParameters(l,string)
        
        print("\n\n\nResult Passed in Views\n")
        """for key in result:
            print(key+"\n")
            print(result[key])
            print()"""

        print(first)
        first = dict(first)
        follow = dict(follow)
        parsing_table = dict(parsing_table)
        print(first)
        print("parsing_table")
        print(parsing_table)
        first = json.dumps(first, cls=SetEncoder)
        follow = json.dumps(follow, cls=SetEncoder)
        parsing_table = json.dumps(parsing_table, cls=SetEncoder)
        #return render(request,'index.html',{ 'first' : first, 'follow':follow, 'parsing_table':parsing_table})
        data = { 
            'first' : first,
            'follow': follow, 
            'parsing_table': parsing_table,
            'msg': msg
        }
        """data = {
        'name':'amit',
        'age':20,
        'lang':{'python':'3','java':2,'c':1}
        }"""
        return JsonResponse(data)
    
    return render(request,'index.html')